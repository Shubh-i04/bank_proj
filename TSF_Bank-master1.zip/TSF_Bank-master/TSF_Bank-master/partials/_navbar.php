<?php

echo '<div class="nevbar" id="nevbar">
    <div class="logo">
        <a href="index.php" id="logo"><h1><span>TSF</span> Bank</h1></a>
    </div>
    <div class="menu" id="menu"> 
        <ul>
            <li><a id="home" href="index.php">Home</a></li>
            <li><a id="home" href="all_user.php">All Users</a></li>
            <li><a id="home" href="create_user.php">Create User</a></li>
            <li><a id="home" href="transfer_money.php">Transfer Money</a></li>
            <li><a id="home" href="transfer_log.php">Transaction Log</a></li>
            <li><a id="home" href="loan.php">Loan</a></li> <!-- Added loan page link here -->

            <li><a id="contact" href="contact.php">Contact</a></li>
        </ul> 
    </div>
    <div class="menuicon">
        <i id="menuicon" onclick="togglemenu()" class="fas fa-chevron-circle-down"> <span>MENU</span></i>
    </div>
</div>
<div class="topspace"></div>';

?>
